import Calculator from './components/calc';
import './App.css';

function App() {
  return (
    <div>
      <Calculator/>
    </div>
  );
}

export default App;
