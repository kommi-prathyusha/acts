import './App.css';
import Count from './components/count';

function App() {
  return (
    <div>
      <Count></Count>
    </div>
  );
}

export default App;
